---
name: design-clone-skill
description: Generate reusable design-system and target-artifact rules from existing design evidence such as website URLs, screenshots, Figma/design files, icons, HTML/CSS, product pages, or reference UI. Use when Codex needs to create or update design.md, target.md, component inventories, clone rules, stress checklists, AI-consumable prompts, or design QA evidence so future HTML, PNG, Figma drafts, prototypes, or local UI edits stay close to the original product instead of drifting into generic AI styling.
---

# Design Clone Skill

Version: 0.2

## Purpose

Create reusable context that helps AI-generated UI preserve a source product's design system and product experience.

This skill does not primarily generate UI. It generates the rule layer used before, during, and after UI generation:

- `design.md`: stable design-system rules extracted from source evidence.
- `target.md`: task-specific product, layout, interaction, and content rules for a known artifact.
- Stress checklist: pressure cases that prove the output survives realistic data, states, and multi-round edits.

## Standard Outputs

Always produce or update:

- `design.md`

When the requested artifact is known, also produce:

- `target.md`
- A stress checklist

When useful for validation, handoff, or multi-agent use, also produce:

- Component Inventory
- `page-registry.md`
- Claude / Cursor / Codex / Figma consumer prompts
- Before/after comparison notes or redline annotations
- `design-analysis.json` summary

## Workflow

1. **Collect source evidence**
   - Identify the source material: URL, screenshot, Figma file, icon set, HTML/CSS, code, or design doc.
   - Identify the product name, source page type, target artifact, and target page type.
   - Decide whether the source provides visual language, target structure, or both.
   - Prefer screenshots, Figma frames, real components, variables, styles, and repeated UI states over metadata, isolated CSS variables, or model assumptions.

2. **Identify the target before extracting layout**
   - Classify the target as website, marketing page, workbench, dashboard, list, form, detail, tool, editor, component, or local edit.
   - Do not copy source page structure literally when it does not match the target. A homepage can provide style evidence without being the right structure for a backend workbench.

3. **Extract durable design rules into `design.md`**
   - Use `references/design-md-template.md`.
   - Capture color roles, brand confidence, token sources, typography, spacing, layout rhythm, components, shape language, assets, information hierarchy, clone rules, adaptive layout rules, anti-AI-flavor rules, and font fallback rules.
   - Keep one-off target requirements out of `design.md`.

4. **Extract artifact rules into `target.md`**
   - Use `references/target-md-template.md`.
   - Capture target type, primary user, first-screen priority, main business object, required modules, source-pattern mapping, component inventory, content inventory, local edit boundaries, interaction states, inspector/detail behavior, permissions, long text, batch actions, anti-patterns, and stress cases.
   - If the target artifact is unknown, record that it is unspecified and ask before final UI generation.

5. **Apply the non-negotiable rule set**
   - Load `references/core-rules.md` when making detailed decisions about cloning, Figma components, adaptive layout, information hierarchy, local edits, redline comparison, production surfaces, text overflow, AI-default bias, evidence-first color, target rules, inspector behavior, real-data stress testing, multi-page registries, or Figma write-back limits.

6. **Generate consumer prompts when another AI will use the rules**
   - Use `references/consumer-prompts.md`.
   - Tell the consumer to read `design.md` first, then `target.md` when present.
   - Make clear that `target.md` overrides generic page conventions for the current artifact.

## Core Rules To Remember

- Reuse or closely clone source components, assets, icons, spacing, typography, and layout patterns before inventing replacements.
- For editable Figma outputs, check for an existing component library first. If none exists and the work must remain editable, create or recommend a task-specific component asset library.
- Use structured layout: flex/grid for HTML; Auto Layout, HUG/FILL, constraints, and component instances for Figma.
- Make information relationships drive spacing and grouping before decoration.
- Keep local edits local. Preserve frozen regions, selected states, detail relationships, scroll position, tab state, and the primary operation path.
- Preserve before/after versions for regression testing, leadership proof, and design QA.
- Keep production workbench, admin, dashboard, editor, and operations surfaces dense, concrete, and work-focused.
- Prevent text overflow with truncation, tooltip behavior, stable widths, and long-text pressure cases.
- Suppress common AI-default styling unless the source proves it: blue-purple gradients, generic SaaS card grids, glassmorphism, floating glow shapes, invented metrics, decorative robots, and fake customer data.
- For Chinese-first UI, do not use `Inter` as the default or primary font. If the source font is unavailable, prefer `Noto Sans SC` / `Noto Sans CJK SC`.
- Low-confidence evidence must affect generation. Do not let weak colors, typography, or layout assumptions drive primary actions, navigation, brand identity, or large visual areas.
- For list/workbench/task/review/asset pages, decide whether an inspector/detail panel is needed and keep it synchronized with the selected item.
- Validate with realistic pressure data: long names, long metadata, many statuses, batch selection, blocked/error/loading/empty states, permission states, dense rows, narrow columns, and mixed Chinese/English text.

## Reference Files

- `references/core-rules.md`: Detailed non-negotiable rules for Design Clone Skill 0.2.
- `references/design-md-template.md`: Template for durable product design rules.
- `references/target-md-template.md`: Template for target-specific product experience rules.
- `references/consumer-prompts.md`: Prompts for Claude, Cursor, Codex, and Figma consumers.

## Quality Check

Before considering the work complete, verify:

- `design.md` names source materials and separates durable design rules from target-specific requirements.
- Color roles include evidence and confidence, not only hex values.
- Token sources are recorded when available.
- Chinese UI avoids `Inter` as the default font and uses a Chinese-first fallback stack.
- Component Inventory is included or recommended when reusable source components exist.
- `target.md` exists when the target artifact is known.
- Local edit boundaries, inspector/detail behavior, stress states, and anti-patterns are explicit.
- Multi-page products include or recommend `page-registry.md`.
- The output explains how future AI generation should preserve the original product system.

