# {{Product Name}} design.md

> Source materials: {{URL / screenshots / Figma / icons / HTML/CSS}}  
> Purpose: Make future AI-generated UI look like it belongs to {{Product Name}}.  
> Pair with `target.md` and a stress checklist when generating a specific artifact such as a dashboard, landing page, Figma screen, or local edit.

## Table of Contents

- 1. Source Summary
- 2. Visual Identity
- 3. Color Roles
- 4. Typography
- 5. Layout And Spacing
- 6. Components
- 7. Component Inventory
- 8. Image And Illustration Rules
- 9. Clone Rules
- 10. Adaptive Layout Rules
- 11. Information Hierarchy Rules
- 12. Anti AI Default Style Rules
- 13. Pairing With target.md
- 14. Multi-Page Registry
- 15. Generation Instructions
- 16. Validation Checklist

## 1. Source Summary

- Product:
- Source type:
- Page / screen type:
- Target users:
- Visual theme: dark-first / light-first / mixed
- Product tone:
- Confidence notes:

## 2. Visual Identity

Describe the source design language in plain words.

Include:

- Overall atmosphere:
- Product category:
- Visual density:
- Layout rhythm:
- Brand feeling:
- What to avoid:

## 3. Color Roles

Do not only list colors. Assign roles and evidence.

### Token Sources

- Figma Variables:
- Figma Styles:
- CSS custom properties:
- Component-local values:
- Screenshot-derived values:
- Token / screenshot conflicts:

### Core Roles

- Background:
- Surface:
- Elevated surface:
- Primary text:
- Secondary text:
- Border / divider:
- Brand color:
- Brand confidence: high / medium / low
- Accent color:
- Accent confidence: high / medium / low
- Status colors:
- Weak references:

### Color Rules

- Preserve dominant background and surface balance.
- Use high-confidence brand colors for primary actions.
- Use medium-confidence colors cautiously.
- Treat low-confidence colors as atmosphere only.
- Do not promote `theme-color`, isolated CSS variables, or AI defaults into brand color without visual evidence.
- Avoid default AI blue / indigo / purple / blue-purple gradients unless source evidence supports them.
- Low-confidence color decisions must not drive primary actions, navigation, large surfaces, or brand identity.
- If a low-confidence color is used in HTML, annotate it with a CSS or HTML comment and include the conservative fallback.
- If a low-confidence color is used in Figma, isolate it in a clearly named layer or note so it can be replaced later.

## 4. Typography

- Font family:
- Chinese-first font stack:
- Latin font usage:
- Font evidence:
- Font fallback when source font is unavailable:
- Inter usage allowed: yes / no, with evidence
- Title scale:
- Section heading:
- Body text:
- Caption / metadata:
- Code / technical text:
- Font weight rules:
- Line-height rules:

## 5. Layout And Spacing

- Page container:
- Grid system:
- Responsive behavior:
- Spacing scale:
- Section rhythm:
- Information density:

Rules:

- Use flex/grid in HTML.
- Use Auto Layout in Figma.
- Avoid scattered layers and brittle absolute positioning.
- Keep related information close and separate unrelated groups.

## 6. Components

Document source component patterns.

### Buttons

- Shape:
- Height:
- Padding:
- Radius:
- Fill:
- Border:
- Text style:
- States:

### Cards / Panels

- Surface:
- Border:
- Radius:
- Padding:
- Shadow:
- Header/body/action layout:

### Forms / Inputs

- Height:
- Border:
- Radius:
- Placeholder:
- Focus:
- Error:

### Navigation

- Structure:
- Active state:
- Hover state:
- Density:

### Lists / Tables

- Row height:
- Column rhythm:
- Dividers:
- Metadata placement:
- Empty/loading/error states:

### Tags / Badges / Pills

- Radius:
- Padding:
- Color logic:
- Status logic:

### Icons

- Source:
- Stroke/fill style:
- Size:
- Alignment:
- When to reuse:

## 7. Component Inventory

List reusable components and source assets before generating new artifacts.

- Component library source: original Figma library / local components / source frames / generated task library / none
- Existing library availability:
- Library fallback plan:

- Component / asset:
- Source location:
- Figma node ID / component key / file path:
- States / variants:
- Resize behavior:
- Text override slots:
- Slot semantics:
- Where to reuse:
- Notes:

Rules:

- For editable Figma outputs, use an existing component library if one is available.
- If no usable component library exists, create or recommend a task-specific component asset library from source patterns.
- Cross-page components must support Auto Layout, HUG/FILL, resize behavior, text overrides, and state variants.
- Page frames should use component instances rather than repeated hand-drawn copies.
- Component text slots must be semantically named so title/value/label/helper/metadata are not accidentally overwritten.

## 8. Image And Illustration Rules

- Product imagery:
- Icons:
- Illustrations:
- Background media:
- Avoid:

## 9. Clone Rules

- Reuse source components, icons, colors, spacing, and layout rhythm whenever possible.
- Do not invent a new visual system.
- New UI should look extended from the source product, not generated from a generic template.
- If modifying a local area, keep unrelated regions unchanged.

## 10. Adaptive Layout Rules

- HTML outputs must use flex/grid and responsive constraints.
- Figma outputs must use Auto Layout, hug/fill, and reusable components.
- Avoid scattered layers and manual patchwork.
- Check long text, empty states, disabled states, and error states for overflow.

## 11. Information Hierarchy Rules

- Analyze information relationships before layout.
- Strongly related items should be visually close.
- Different groups should be separated with larger spacing.
- Use typography, spacing, and grouping before decoration.

## 12. Anti AI Default Style Rules

- Avoid default AI blue / indigo / purple unless source evidence supports it.
- Avoid generic SaaS cards, over-rounded components, decorative glow blobs, and arbitrary gradients.
- Avoid replacing the source palette with trendy AI-product colors.
- Do not use a color as brand just because it appears in metadata.
- For Chinese-first product UI, do not use `Inter` as the primary/default font.
- If `PingFang SC` or another source Chinese font is unavailable, use `Noto Sans SC` / `Noto Sans CJK SC` before considering any Latin UI font.

### Known AI Default Biases To Suppress

- Blue-purple gradient avatars, assistant marks, badges, or CTA treatments:
- Invented stat rows, analytics counters, health metrics, or productivity claims:
- Square colored navigation icons used as generic module markers:
- Generic SaaS card grids replacing dense product workflows:
- Glassmorphism, heavy blur, floating glow backgrounds, orb decorations, or dramatic hero sections:
- Over-rounded white cards with heavy shadows in flat or dense workbench products:
- Decorative Lottie-style motion, mascots, robots, or atmospheric illustration in operational UI:
- Fake feature descriptions, invented module previews, unsupported customer names, or benchmark numbers:
- Latin-first font stacks in Chinese-first interfaces:
- `Inter` used as default font in Chinese-first product UI:
- Newly discovered model-specific biases:

## 13. Pairing With target.md

Use this `design.md` as the stable design-system source of truth.

When a specific artifact is requested, create a separate `target.md` using `references/target-md-template.md`. For product UI, the default context should be `design.md + target.md + stress checklist`.

Rules:

- Keep this file focused on durable design-system rules.
- Put one-off page requirements, target page type, primary user job, business objects, content inventory, layout mapping, operation path, states, exceptions, and artifact-specific anti-patterns in `target.md`.
- Put real-data pressure cases such as long text, dense metadata, batch selection, empty/loading/error states, and permission states in the target stress checklist.
- Source materials provide style evidence, but not always target structure. Do not copy a homepage, hero, preview panel, or marketing section into a backend page just because it exists in the source.
- If the target artifact is unknown, write: "Target artifact is not specified; ask for target artifact before generating final UI."

## 14. Multi-Page Registry

For products with multiple page types, maintain or recommend `page-registry.md`.

- Page type:
- Source frame / source URL:
- Target rules file:
- Reusable components:
- Known states:
- Validation notes:
- Drift risks:

## 15. Generation Instructions

When generating HTML / PNG / Figma / prototypes:

- Read this `design.md` first.
- Read `target.md` second if present.
- Preserve source design language.
- Reuse existing component patterns.
- Follow target-specific rules from `target.md` if present.
- Identify the target page type and first-screen job before choosing layout.
- Use structured adaptive layout.
- Keep local edits local.
- For workbench/list/detail pages, keep selected rows/cards, inspector/detail panels, and actions synchronized.
- Validate generated UI with stress cases before treating it as stable.
- Check whether a new page type is covered by this design.md before generating; if not, extend rules first.
- For Figma writes, clone original assets, respect tool-chain limits, and validate with screenshots.
- Explain any unavoidable deviation.

## 16. Validation Checklist

- Looks like the source product:
- Uses correct color roles:
- Uses Chinese-first font fallback rules:
- Does not use `Inter` as default font in Chinese-first UI:
- Brand color confidence respected:
- Low-confidence decisions annotated:
- Token source respected:
- No unsupported AI blue/purple:
- Layout is structured:
- Components follow source patterns:
- Component Inventory reused:
- `target.md` is followed when present:
- Target page type and primary user job are clear:
- Source page structure does not overpower target task:
- `page-registry.md` followed when present:
- Information hierarchy is clear:
- Local edits do not redraw unrelated regions:
- Product interaction states and stress cases are covered:
- Before / after or redline evidence produced when useful:
