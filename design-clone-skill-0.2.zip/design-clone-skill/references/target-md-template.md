# {{Product Name}} target.md

> Pair with: `design.md`  
> Target artifact: {{dashboard / landing page / HTML prototype / Figma screen / local edit / component / image}}  
> User goal: {{what the user wants to generate or change}}

## Table of Contents

- 1. Target Summary
- 2. Required Modules
- 3. Required Business Objects
- 4. Source Pattern Mapping
- 5. Component Inventory
- 6. Layout Rules
- 7. Information Hierarchy
- 8. Product Interaction Rules
- 9. Component Relationship Priority
- 10. Component Rules
- 11. Content Inventory
- 12. Anti-Patterns
- 13. Stress Test Cases
- 14. Compare / Redline Requirements
- 15. Validation Checklist

## 1. Target Summary

- Target artifact:
- Output format:
- Page type: website / workbench / dashboard / list / form / detail / tool / editor / local edit / component
- Primary user:
- Primary job:
- First-screen priority:
- Main business object:
- Source design system:
- Success criteria:
- Source provides: visual language / target structure / both
- Source structure that must not be copied literally:

## 2. Required Modules

List the modules that must appear in this artifact.

- Module:
- Purpose:
- Source pattern to reuse:
- Required content:
- Priority:
- First-viewport requirement:
- Related business object:

## 3. Required Business Objects

Name the real objects the artifact must contain so the output does not become generic.

- Object:
- Fields / metadata:
- States:
- Actions:
- Example copy:
- Owner / actor fields:
- Detail / inspector fields:
- Long-text pressure examples:

## 4. Source Pattern Mapping

Map source UI patterns to the new artifact.

- Source pattern:
- How to reuse or clone it:
- Where it appears in the target:
- What not to reuse:
- If source is a marketing/homepage component, how it should be translated into the target page instead of copied literally:

## 5. Component Inventory

List source components and assets that should be reused before generating new UI.

- Component library source: original Figma library / local components / source frames / generated task library / none
- Existing library lookup result:
- If no library exists, task-specific component library required: yes / no

- Component / asset:
- Source pattern:
- Figma node ID / component key / file path:
- States / variants:
- Resize behavior:
- Auto Layout behavior:
- Text override slots:
- Slot semantics:
- Required modifications:
- Where it appears in the target:
- Fallback if unavailable:

Rules:

- Prefer importing, cloning, or adapting listed components over rebuilding with generic shapes.
- Preserve source details such as icon glyphs, folds, shadows, constraints, selected states, and spacing.
- If a needed component is missing, create the closest source-consistent extension and record it as a new component candidate.
- For editable Figma outputs, page frames should be assembled from component instances whenever possible.
- Cross-page components must support resize, text overrides, state variants, and clear slot semantics.
- Components must distinguish title, value, label, helper text, metadata, and badge copy so local edits do not overwrite the wrong text.
- If the output is static HTML/PNG, a component library is optional; if the output is editable Figma and intended for continued design work, a component source is required or the exception must be documented.

## 6. Layout Rules

- Page structure:
- Grid / columns:
- Primary focus area:
- Secondary areas:
- First-screen task:
- Selected item / detail relationship:
- Inspector / detail panel needed: yes / no / unknown
- Inspector content must correspond to:
- Responsive behavior:
- Density:
- Local edit stability:
- Frozen regions:
- Editable regions:
- First-viewport content that must stay visible:
- Page registry entry:
- Related page types:

Rules:

- Local edits must keep unrelated regions unchanged.
- Before a local edit, state which regions are frozen and which region is editable.
- Frozen regions must keep their layout, copy, component style, spacing, colors, and hierarchy unchanged.
- Local edits must also preserve the edited region's internal quality.
- Check whether changed copy, added rows, new statuses, or longer metadata cause crowding, overlap, clipping, overflow, or push important content out of the first viewport.
- Sibling items in the same visual group should use consistent spacing tokens in horizontal and vertical directions.
- For multi-round edits, compare against the previous output and prevent gradual drift toward generic AI defaults.
- For new page types, confirm `design.md` covers the layout pattern before final generation.
- If this belongs to a multi-page product, update or recommend `page-registry.md`.
- If adding a local feature, keep it near the related business object and do not reorganize the whole page.
- If adding a new region, classify it as queue / inspector / toolbar / drawer / modal / toast / log / settings before placing it.
- Preserve selected state, scroll position, tab state, detail relationship, and primary operation path across iterations.

## 7. Information Hierarchy

- Primary information:
- Secondary information:
- Metadata:
- User first action:
- Main operation path:
- Related row/card/detail states:
- Strongly related groups:
- Groups that need separation:
- Spacing notes:

## 8. Product Interaction Rules

- Primary operation path:
- Secondary operation path:
- Selection behavior:
- Batch action behavior:
- Hover-only secondary actions:
- Immediate feedback:
- Loading feedback threshold:
- Delete / undo / confirmation:
- New item highlight:
- Return-to-list behavior:
- Permission / approval behavior:
- Empty state:
- Loading state:
- Error / blocked state:
- Toast / message / log behavior:
- Drawer / modal usage limits:
- Anti-patch rules:

Rules:

- Batch actions should appear only after selection unless the source product says otherwise.
- High-risk irreversible operations may use confirmation; reversible delete should prefer undo feedback.
- Feedback should appear close to the action or business object it belongs to.
- Inspector, list row, and operation feedback must stay synchronized.
- New information must enter the existing information architecture rather than floating as a patch.

## 9. Component Relationship Priority

Classify every new feature before placing it:

- Strongly related to current row/card:
- Related to current list/queue:
- Related to global system:
- Related to async feedback:
- Related to complex approval/configuration:
- Placement decision:
- Why this placement preserves the main workflow:

Rules:

- Row-related features belong in row, card, or inspector.
- List-related features belong in queue toolbar, filter area, or batch action area.
- Global status belongs in sidebar, global header, or status strip.
- Async feedback belongs in toast, progress, or log.
- Complex approval/configuration may use drawer or modal, but should not hide key selected-object context.

## 10. Component Rules

- Buttons:
- Lists / tables:
- Cards / panels:
- Tags / badges:
- Badge max width / truncation / wrap behavior:
- Table column priority:
- Long-copy behavior:
- Tooltip behavior for truncated text:
- Components that must stay single-line:
- Right-panel / drawer scroll behavior:
- Inputs / filters:
- Navigation:
- Empty / loading / error states:
- Icon usage / emoji ban:
- Shadow / hover / motion restraint:
- Data authenticity rules:
- Placeholder / filler-copy rules:
- Low-confidence visual decisions:
- HTML comments / Figma notes required for low-confidence decisions:

## 11. Content Inventory

Include concrete labels, statuses, sample names, and values.

- Navigation labels:
- Section titles:
- Status names:
- Sample rows:
- Sample metrics:
- Sample actions:
- Sample technical text:

## 12. Anti-Patterns

The output must not become:

- Generic page type:
- Wrong product style:
- Wrong color behavior:
- Wrong content objects:
- Wrong layout pattern:
- AI-default drift to avoid:
- AI-flavor patterns to suppress:
- Emoji / icon misuse to avoid:
- Unsupported data or claims to avoid:
- Production surface violations:
- Known AI default biases to suppress:
- Source component overpowering target task:
- Pretty but unusable areas:
- Patch-like additions:

## 13. Stress Test Cases

Use realistic data pressure to expose fragile layout.

- Very long item name:
- Very long metadata:
- Multiple status tags:
- Batch selection:
- Error / blocked state:
- Empty state:
- Loading state:
- Permission denied / approval pending / read-only:
- Long Chinese text:
- Mixed Chinese/English technical text:
- Narrow viewport / dense-row case:
- Expected behavior for each case:

Optional validation artifact:

- `stress-test.html` required: yes / no
- Baseline view:
- Multi-round edit view:
- Error / exception view:
- Comparison report view:

## 14. Compare / Redline Requirements

Use when the artifact is part of QA, regression testing, stakeholder review, or a multi-version exploration.

- Baseline version:
- New version:
- Regions that must stay unchanged:
- Regions intentionally changed:
- Differences to annotate:
- Redline categories: color / typography / spacing / component / hierarchy / overflow / behavior
- Before / after output required:

Rules:

- Do not overwrite the baseline when comparison is needed.
- Label versions clearly.
- Use annotations to explain meaningful differences and defects.
- Treat redlines as validation evidence.

## 15. Validation Checklist

- Uses `design.md` visual system:
- Follows this `target.md`:
- Target page type is identified before generation:
- Current page's main object is clear:
- First screen solves the primary user job:
- Source page structure does not overpower the target task:
- Contains required modules:
- Contains required business objects:
- Reuses Component Inventory:
- Reuses source patterns:
- Avoids listed anti-patterns:
- Uses structured adaptive layout:
- New page type is registered or documented:
- Low-confidence decisions are annotated:
- Local edits keep unrelated regions unchanged:
- New functionality is near the related business object:
- New modules do not feel pasted on:
- Existing selected state, detail relation, tab state, and main operation path are preserved:
- Inspector / detail panel corresponds to the current selected item:
- Component relationship priority is respected:
- Edited regions still handle long copy / added rows / status changes:
- Stress data cases pass:
- Batch actions appear only when appropriate:
- Empty/loading/error/permission states are covered:
- Tags, buttons, inputs, and table cells use ellipsis plus tooltip instead of overflow or unwanted wrapping:
- Avoids AI-flavor patterns such as emoji icons, unsupported blue-purple gradients, heavy shadows, generic feature blocks, lorem ipsum, and invented metrics:
- Avoids pretty-but-not-useful regions:
- Multi-round edits do not drift toward generic SaaS / AI-default colors:
- Tables, badges, and panels handle density without crowding or overflow:
- Before / after or redline evidence is produced when useful:
- Remains editable / locally modifiable:
