# Consumer Prompts

Use these prompts after generating `design.md`.

## Table of Contents

- Universal Prompt
- Codex Prompt
- Claude Prompt
- Cursor Prompt
- Figma Prompt

## Universal Prompt

```text
Read the attached design.md first. If a target.md is provided, read it second and treat it as the task-specific rule layer.

Generate the requested UI so it looks like an extension of the source product's existing design system.

Rules:
- Reuse source colors, typography, spacing, radius, component patterns, icon style, and layout rhythm.
- Follow target.md when present. It has higher priority than generic page conventions for this specific output.
- Before generating, identify the target page type and primary user job. Do not let the source page structure overpower the target artifact.
- Treat design.md as the durable visual/design-system layer and target.md as the product/task layer.
- Reuse the Component Inventory when provided. Clone/import listed components before creating new ones.
- For editable Figma outputs, first check whether an original component library, local components, variables, or styles exist. Use them before creating new components.
- If no usable Figma component library exists and the output must remain editable across pages, create or recommend a task-specific component asset library with Auto Layout, resize behavior, text overrides, and state variants.
- Use structured adaptive layout: flex/grid for HTML, Auto Layout for Figma.
- Do not invent a new visual system.
- Do not use default AI blue, indigo, purple, or blue-purple gradients unless design.md says the source uses them with strong evidence.
- For Chinese-first UI, do not use `Inter` as the default or primary font. If the source Chinese font is unavailable, use `Noto Sans SC` / `Noto Sans CJK SC` as the preferred fallback.
- Low-confidence colors, typography, or layout decisions must stay conservative. If used in HTML, annotate them in comments with evidence and fallback. If used in Figma, isolate them with clear layer names or notes.
- If only one region needs changing, keep the rest of the page unchanged.
- For local or multi-round edits, place new functionality near the related business object, preserve selected states, and do not reorganize the whole page unless asked.
- For workbench/list/queue/detail pages, decide whether an inspector/detail panel is needed and keep it synchronized with the selected item.
- Classify new features by relationship before placing them: row/card, list/queue, global system, async feedback, or complex approval/configuration.
- Validate with stress data: long names, long metadata, multiple statuses, batch selection, empty/loading/error states, and permission or approval constraints.
- If comparison or QA is requested, preserve the baseline and create a new version instead of overwriting it.
- For multi-page products, check page-registry.md when present and avoid drifting into a new interpretation for each page.
- Before generating, identify which source patterns from design.md and which target rules from target.md you are reusing.
```

## Codex Prompt

```text
Use design.md as the design-system source of truth. If target.md exists, use it as the target artifact source of truth.

Implement or modify the UI using the existing product style. Keep edits scoped. Preserve layout, density, component behavior, color roles, and target artifact rules. If creating HTML, use responsive flex/grid. If creating Figma, use Auto Layout and clone source-like components instead of hand-drawing generic replacements.

Operational constraints:
- Use Component Inventory and page-registry.md when present.
- Determine whether this is a website, dashboard, list, form, detail page, tool page, editor, component, or local edit before choosing layout.
- Use target.md to define the first-screen priority, main business object, operation path, states, exceptions, and anti-patterns.
- For Figma, assemble pages from component instances when possible. Do not repeatedly hand-draw sidebar, button, input, chip, card, table row, tab, avatar, or file badge structures.
- Components must have clear slot semantics for title, value, label, helper text, metadata, and badge copy.
- Do not default to `Inter` in Chinese product UI. Prefer the source Chinese font; if unavailable, use `Noto Sans SC` / `Noto Sans CJK SC`.
- Keep multi-round edits local: new features should attach to the relevant row/card/inspector/toolbar/toast/drawer instead of becoming a global patch.
- For operational pages with selectable objects, keep list row, selected state, inspector/detail panel, and available actions aligned.
- Run or document stress checks for long text, dense data, batch selection, error/loading/empty states, and permission states.
- Treat low-confidence evidence as a conservative fallback, not as brand direction.
- Preserve previous versions when generating comparison variants.
- Add lightweight comments or notes for low-confidence visual decisions and intentional deviations.
```

## Claude Prompt

```text
You are working under the attached design.md.

First extract the relevant rules for this task from design.md and target.md if present, then generate the requested artifact. The output must preserve source visual identity, brand confidence, color roles, component patterns, spacing, and information hierarchy. Do not introduce unsupported AI-default blue/purple styling.

Use Component Inventory before drawing new UI. Identify the page type and primary user job before choosing layout. If source material is a homepage or marketing page but the target is a backend/product surface, translate visual patterns into target-appropriate modules instead of copying the source structure literally. If a visual decision is low-confidence, choose a conservative fallback and annotate the decision. If this is a new page type in a multi-page system, check whether the layout pattern is covered before generating.

For Chinese-first UI, never choose `Inter` as the default font. Use the source Chinese font when available; otherwise use `Noto Sans SC` / `Noto Sans CJK SC` as the preferred fallback.

For local edits, keep changes close to the related object and preserve existing selected/detail relationships. For list, queue, review, ticket, approval, task, or asset pages, decide whether an inspector/detail panel is required and keep it synchronized with the selected item. Validate the result with stress data including long text, multiple statuses, batch selection, empty/loading/error states, and permission constraints.

For editable Figma work, prefer existing component libraries. If none exist, create/recommend a task-level component asset library so future edits can resize, override text, switch states, and remain consistent across pages.
```

## Cursor Prompt

```text
Before coding, read design.md and treat it as project design rules.

When generating components or pages:
- use existing source patterns,
- keep local changes local,
- avoid generic template styling,
- follow target.md before generic dashboard/page conventions,
- identify the target page type and primary user job before choosing layout,
- keep source page structure subordinate to the target task,
- respect color roles and brand confidence,
- avoid `Inter` as the default font in Chinese-first UI; use `Noto Sans SC` / `Noto Sans CJK SC` if the source font is unavailable,
- annotate low-confidence visual choices,
- reuse Component Inventory and page registry rules when present,
- use existing Figma components first; generate a task component library only when no usable source library exists,
- keep local edits local and place new functionality near its related business object,
- keep inspector/detail panels synchronized with selected rows or cards,
- include stress states for long text, batch actions, empty/loading/error, and permission cases,
- keep previous versions intact for comparison work,
- prefer layout primitives that remain responsive and editable.
```

## Figma Prompt

```text
Create or modify the Figma design according to design.md.

Use existing assets/components whenever possible. Use Auto Layout for frames, cards, lists, buttons, badges, forms, and panels. Do not use scattered layers or manual patchwork. Preserve source color roles, typography, radius, spacing, density, and information grouping.

Clone original assets before editing. Reuse Component Inventory entries. For editable Figma outputs, check existing local/team components, variables, and styles first. If none are usable and the design must be edited or reused across pages, create or recommend a task-specific component asset library with Auto Layout, HUG/FILL resize behavior, text override slots, and state variants. If fonts, component variants, or remote styles cannot be safely applied through Figma tooling, use the approved fallback, keep the original untouched, and add a note explaining the deviation. For Chinese UI, the fallback should prefer `Noto Sans SC` / `Noto Sans CJK SC` and should not fall back to `Inter`. Preserve baseline frames when producing alternatives or redline comparisons.

Before building the frame, identify the target page type, primary business object, first-screen priority, and main operation path from target.md. For list/workbench/detail pages, decide whether an inspector/detail panel is needed and keep it tied to the selected item. Local edits should preserve existing structure and appear near the related object. Add or document stress cases for long text, dense metadata, batch selection, empty/loading/error states, and permission states.
```
