# Design Clone Skill Core Rules

> Version: 0.2  
> Load this file when you need the detailed, non-negotiable rules behind the standard `design-clone-skill` workflow.

## Table of Contents

- Goal
- Inputs
- Workflow
- Non-Negotiable Rules
- Output Requirements
- Quality Check
- When Unsure

## Goal

Generate a high-quality `design.md` from source design materials so future AI-generated UI looks like it belongs to the original product. When the user has a specific output in mind, also generate a focused `target.md` and stress checklist for that artifact.

This skill does not primarily generate UI. It generates reusable design context, target-specific product rules, and validation pressure cases.

## Inputs

Accept any useful source material:

- Website URL
- Page screenshot
- Figma/design file or exported frames
- Icons, logos, illustrations, product images
- HTML/CSS snippets or existing frontend code
- Existing design system documentation

If multiple inputs conflict, prioritize visual evidence from screenshots or design files over metadata, unused CSS variables, and model assumptions.

## Workflow

1. Collect evidence
   - Identify source type, product name, page type, and target output.
   - If the user names a target artifact such as dashboard, app page, landing page, Figma screen, HTML prototype, image, or local edit, treat that target as a first-class requirement.
   - Identify the product goal before extracting layout: website / marketing page, workbench, dashboard, list page, form page, detail page, tool page, editor, component, or local modification.
   - Decide whether the source material provides visual language only, target structure only, or both. A source website can provide style evidence without being the right structure for a backend page.
   - If URL is provided, inspect the live page, screenshot, HTML/CSS, icons, and images when tools allow.
   - If screenshots/design files are provided, analyze them as primary visual evidence.
   - If icons/assets are provided, capture their shape language, stroke weight, fill style, and usage rules.

2. Extract design language
   - Color roles: background, surface, text, brand, accent, status, border, weak references.
   - Brand confidence: high / medium / low, with evidence.
   - Token sources: Figma Variables, Styles, CSS custom properties, component-local values, and screenshot-derived values. Prefer authoritative design-system tokens over sampled colors when they are available and visually confirmed.
   - Typography: font family, size scale, weights, line height, hierarchy.
   - Layout: grid, spacing scale, density, page rhythm, responsive behavior.
   - Components: buttons, cards, inputs, tags, dropdowns, tabs, tables, lists, nav, modals, toasts, component source IDs, and reusable variants.
   - Shape and effects: radius, border, shadow, blur, dividers, overlays.
   - Information hierarchy: grouping, proximity, emphasis, scan path.

3. Write `design.md`
   - Use the structure in `references/design-md-template.md`.
   - Keep it specific enough for AI tools to execute.
   - Include evidence notes for important decisions.
   - Include clone rules, adaptive layout rules, local edit rules, and anti AI-default-color rules.
   - Keep `design.md` stable and reusable. Do not bury one-off page requirements inside it.

4. Write `target.md` when a target artifact is known
   - Use the structure in `references/target-md-template.md`.
   - Make it short, operational, and specific to the requested artifact.
   - Include target type, primary user, first-viewport job, required modules, business objects, component inventory, content inventory, source-pattern mapping, page-specific hierarchy, and anti-patterns.
   - Include product experience rules: main operation path, selected state, detail/inspector behavior, empty/loading/error states, permissions, long text, batch actions, and local edit boundaries.
   - Include a stress checklist for real data: long names, long metadata, multiple statuses, batch selection, blocked/error states, empty/loading states, and permission or approval constraints.
   - For multi-page products, record the page type and target rules in a page registry or recommend creating `page-registry.md`.
   - If the target is unknown, do not invent `target.md`; ask for or record that the target artifact is unspecified.

5. Generate consumption prompts when useful
   - For Claude / Cursor / Codex, use `references/consumer-prompts.md`.
   - Prompts should tell the AI to read `design.md` first, then `target.md` if present, reuse source patterns, avoid repainting whole pages for local edits, and preserve design-system consistency.

## Non-Negotiable Rules

### Clone Existing Assets

If source components, layout structures, icons, or visual patterns exist, reuse or closely clone them. Do not redraw generic substitutes unless no source pattern exists.

When working from Figma or a component library:

- First check whether the Figma file already has local components, subscribed team libraries, variables, styles, or reusable source frames.
- Prefer the original Figma component library when it exists and can be called.
- Scan for existing components, variants, icons, table rows, list items, empty states, toolbars, cards, avatars, and file-type badges before generating.
- Record reusable component names, node IDs, component keys, or source file paths in `target.md` under Component Inventory.
- Prefer cloning or importing existing components over rebuilding with rectangles and text.
- Preserve asset details such as icon folds, glyphs, shadows, selected states, hover states, text styles, constraints, and Auto Layout.
- If a needed component does not exist, state that it is new and define the closest source pattern it should extend.

### Figma Component Library Discipline

Component libraries solve Figma editability and cross-page consistency. `design.md` can describe what a product should look like, but a Figma component library defines how elements are reused, resized, overridden, and kept structurally stable.

Use this decision path:

- If the target is HTML, PNG, or a static visual, `design.md + target.md` may be enough.
- If the target is an editable Figma design, always check for an existing component library first.
- If an original Figma component library exists, use it before creating new components.
- If no usable library exists, create or recommend a task-specific component asset library derived from the source design.
- If components will be reused across pages, they must support Auto Layout, resize behavior, text overrides, clear slot semantics, and state variants.
- Page frames should be assembled from component instances whenever possible; do not repeatedly hand-draw sidebar, button, input, chip, card, table row, tab, avatar, or file badge structures.
- Component internals must distinguish semantic text slots such as title, value, label, helper text, metadata, and badge copy so later edits do not overwrite the wrong text.
- Components should use stable HUG/FILL behavior, constraints, min/max sizing, truncation, and tooltip notes so resizing does not cause text overlap, border leakage, or layout collapse.
- For local edits, change component instances, variants, or named slots rather than rebuilding nearby layout.
- A Figma output intended for design handoff is incomplete if it is only scattered frames/text without a reusable component source or a documented reason why components were not created.

### Structured Adaptive Layout

Use structured layout rules:

- HTML: flex/grid and responsive constraints.
- Figma: Auto Layout with hug/fill behavior.
- Avoid scattered layers, absolute-positioned patchwork, and brittle manual placement.

### Information Relationship First

Do not simply list content. Analyze which information belongs together.

- Strongly related content: tighter spacing, usually 4 / 8 / 12px.
- Different groups: wider spacing, usually 16 / 20 / 24px.
- Use spacing, typography, and component grouping to make relationships readable.

### Local Edits Stay Local

If the user asks to modify one area, preserve the rest of the page. Do not regenerate or redesign the whole page unless explicitly requested.

For local edits:

- Explicitly identify frozen regions and editable regions before changing the output.
- Keep unrelated layout, copy, components, spacing, colors, and hierarchy unchanged.
- Preserve the edited region's internal quality, not just the rest of the page.
- Check whether longer copy, added rows, new statuses, or changed metadata create crowding, overlap, clipping, overflow, or first-viewport displacement.
- For multi-round edits, compare against the previous output and guard against gradual style drift.
- When making alternatives for comparison, keep the previous version intact and create a new variant next to or below it.

### Version Comparison And Redline Workflow

When the task involves validation, regression testing, design QA, or showing value to stakeholders:

- Preserve before / after versions rather than overwriting the original.
- Generate or recommend a comparison artifact that lists changed regions, preserved regions, and intentional deviations.
- For Figma, place new frames near the source frame and label versions clearly.
- For HTML, provide a difference report or annotation view when useful.
- Use redline-style annotations for spacing, color, typography, component replacement, overflow, and hierarchy mismatches.
- Treat annotations as QA evidence, not decoration.

### Production Surface Discipline

When the target is a production workbench, admin console, dashboard, editor, or operations page, keep the surface work-focused:

- Prefer dense but readable tables, lists, panels, filters, and metadata over marketing cards.
- Do not introduce blue primary buttons, blue-purple gradients, decorative hero blocks, or generic SaaS card styling unless the source evidence supports them.
- Keep business objects concrete: rows, statuses, owners, timestamps, channels, queues, inventories, logs, reviews, or other domain-specific objects.
- Define table column priority, badge width behavior, long-copy wrapping, and right-panel scroll behavior in `target.md` when relevant.

### Text Overflow And Tooltip Discipline

Interactive and data-dense UI must not break because text is too long.

- Tags, badges, buttons, inputs, filters, table cells, list rows, tabs, menu items, and compact metadata should stay single-line unless the source system explicitly uses multiline text.
- If text does not fit, use ellipsis truncation instead of overflow or forced wrapping.
- Provide the full value on hover with a tooltip or native `title` attribute in HTML outputs.
- In Figma outputs, keep the visible label truncated and add a note describing the intended tooltip behavior.
- Long-form content areas such as descriptions, notes, comments, empty states, and documentation blocks may wrap, but only inside a defined container with stable width and line height.
- Never allow long labels to resize buttons, badges, table columns, navigation items, or filters in a way that shifts the layout.

### Anti AI-Flavor Discipline

Suppress common AI-generated UI habits unless the source design clearly uses them.

- Do not use emoji as functional icons. Use the source icon system, product icon library, or simple text labels. If no icon system exists, prefer restrained line icons with consistent size, stroke, and color.
- Do not overuse lucide-style icons just to fill space. Icons must serve a clear function and match the source icon language.
- Do not create default blue-purple / indigo gradients, gradient hero sections, colorful glow backgrounds, floating orbs, or decorative abstract waves without source evidence.
- Do not default to oversized rounded cards, white cards with heavy shadows, colorful left borders, or card-heavy dashboard layouts when the source is denser or flatter.
- Do not use big display typography, oversized headings, or inflated spacing inside workbench/admin/productivity interfaces unless the source does.
- Do not use exaggerated hover shadows, lift effects, glassmorphism, blur panels, or dramatic transitions unless the source system explicitly has them.
- Do not use generic feature blocks such as Feature 1 / Feature 2 / Feature 3, lorem ipsum, placeholder slogans, or filler text to make a page look complete.
- Do not invent unsupported metrics, claims, charts, productivity gains, customer names, testimonials, or benchmark numbers. Use real source data, user-provided examples, or clearly marked placeholders.
- Do not replace product-specific structure with generic SaaS sections such as hero, pricing, testimonials, generic analytics cards, or marketing CTAs unless the target is actually that page type.
- Do not copy the model's default font stack as a design decision. Extract and follow the source typography; if evidence is weak, keep typography neutral and document uncertainty.
- For Chinese UI, do not use `Inter` as the default or primary interface font. Do not put `Inter` before Chinese fonts in Chinese-first interfaces.
- For Chinese UI without a proven product font, prefer a Chinese-first font stack such as `PingFang SC`, `Noto Sans SC`, `Noto Sans CJK SC`, `Microsoft YaHei`, `Source Han Sans SC`, `Hiragino Sans GB`, then system sans-serif.
- If `PingFang SC` or another source font is unavailable in the target environment, use `Noto Sans SC` / `Noto Sans CJK SC` as the preferred fallback instead of `Inter`.
- Use `Inter`, `Roboto`, or other Latin UI fonts only when the source product clearly uses them and the interface is primarily Latin-script.
- Do not add stock-like illustrations, AI mascots, decorative robots, or atmospheric images when the task is product UI, admin UI, or design-system-consistent output.
- Do not use colorful pseudo-data visualizations just to decorate. Charts and metrics must correspond to required business objects.

### Known AI Default Bias Register

Maintain and extend this list when new model habits are discovered. If a generated output shows one of these patterns without source evidence, treat it as a defect:

- Blue-purple gradient avatars, assistant marks, badges, or CTA treatments.
- Invented stat rows, analytics counters, health metrics, or productivity claims.
- Square colored navigation icons used as generic module markers.
- Generic SaaS card grids replacing dense product workflows.
- Glassmorphism, heavy blur, floating glow backgrounds, orb decorations, or dramatic hero sections.
- Over-rounded white cards with heavy shadows in flat or dense workbench products.
- Decorative Lottie-style motion, mascots, robots, or atmospheric illustration in operational UI.
- Fake feature descriptions, invented module previews, unsupported customer names, or benchmark numbers.
- Latin-first font stacks in Chinese-first interfaces.
- `Inter` used as the default font in Chinese-first product UI.
- New default patterns introduced by a model version. Add them here after a failed test so the skill becomes stronger over time.

### Evidence-First Color

Do not let AI default aesthetics override the source.

- Treat screenshots and actual components as strongest evidence.
- Treat `theme-color`, isolated CSS variables, and model defaults as weak evidence.
- Do not promote blue, indigo, purple, or blue-purple gradients into brand/accent roles unless they appear in screenshots, source components, or repeated active styles.
- If the source has no blue/purple identity, avoid AI-default blue/purple buttons, glows, badges, gradients, and hero effects.

### Brand Confidence

Assign confidence to brand/accent colors:

- High: appears in core source components, repeated CSS tokens, visible brand marks, or both screenshot and CSS.
- Medium: appears in screenshot or CSS but not enough to prove it is the brand color.
- Low: likely atmosphere, status, decoration, or weak evidence.

Only high-confidence brand colors should drive primary buttons, CTAs, and key highlights. Medium colors should be used cautiously. Low-confidence colors should be treated as atmosphere only.

### Confidence Must Affect Generation

Confidence is not only documentation. It must change how generated UI behaves:

- High-confidence colors, typography, components, and layout patterns may be used as strong rules.
- Medium-confidence evidence should be used cautiously and should not dominate the page.
- Low-confidence evidence must not drive primary actions, navigation, brand identity, or large visual areas.
- In HTML outputs, any low-confidence visual decision that is still used must include a CSS or HTML comment explaining the evidence and the conservative fallback.
- In Figma outputs, low-confidence visual decisions should be isolated in clearly named layers or notes so they can be replaced when stronger evidence appears.
- When evidence is low, prefer neutral surfaces, source-confirmed text styles, and conservative system behavior over colorful invention.

### Design Token Source Of Truth

When design-system tokens are available, make them the primary source of reusable rules:

- Prefer Figma Variables and Styles for color, spacing, radius, typography, and effects.
- Prefer named CSS custom properties or theme tokens over one-off sampled values.
- If tokens and screenshots disagree, record the conflict and prefer the screenshot for immediate visual cloning while noting the token mismatch.
- When the source design changes, diff tokens before rewriting visual rules.
- Record token names where possible, not only hex values.
- Do not create near-match colors when an authoritative token exists.

### Target Artifact Rules Live In `target.md`

A useful generation context has two layers:

- `design.md`: stable design-system rules extracted from source materials.
- `target.md`: target-specific rules for the requested artifact.

Do not let `design.md` become a long mix of permanent design rules and one-off page instructions. Put target-specific details in `target.md`.

When the target artifact is known:

- Name the target artifact type.
- Identify the product goal before generating. The same visual system may produce a landing page, dashboard, list, form, detail page, tool page, editor, or local edit, and each has different structure.
- List required modules, business objects, and content inventory.
- Define the first-screen priority: what the user must understand or act on first.
- Define the main operation path: entry point, selected object, primary action, feedback, and completion state.
- Map source patterns to the new artifact. Example: editor panels become workspace panels; code snippets become review/diff blocks; model chips become routing controls.
- Treat source page structure as evidence, not destiny. A source homepage's hero, IDE preview, CLI block, or marketing section can be translated into product modules, but should not occupy a workbench first screen unless that is the target task.
- State what the artifact must not become. Example: a developer dashboard should not become a generic sales analytics dashboard.
- Include domain-specific labels, status names, metadata, and sample content so the generator does not invent a generic page.
- Keep target rules shorter and more operational than the brand analysis.

If the target artifact is unknown, record that the target is unspecified and ask for it before generating final UI.

### Multi-Round Local Edit Stability

Design clone work often proves its value across repeated edits, not only the first generation. For every local or multi-round edit:

- New functionality must appear near the related business object.
- Do not reorganize the whole page to add one feature.
- Do not paste local explanations into unrelated global areas.
- If a new region is needed, classify it first as queue, inspector, toolbar, drawer, modal, toast, log, or settings.
- Preserve existing selected states, detail relationships, scroll position, tab state, and primary operation path unless the user explicitly changes them.
- New states must be reflected at the correct level: list row, selected detail, log/feed, toast, or global status.
- Added content must enter the existing information architecture rather than looking like an attached patch.

### Inspector And Detail Panel Rules

For workbench, admin, list, queue, review, alert, ticket, task, conversation, approval, or asset-management pages, decide whether a selected-item inspector or detail panel is needed.

- If the page has a selectable operational object, consider an inspector.
- The inspector must always describe the current selected item.
- Do not show unrelated help, marketing copy, or generic summaries in the inspector.
- Row state, selected state, inspector content, and available actions must stay synchronized.
- Complex flows can use drawer or modal only when they do not hide the essential selected-object context.

### Component Relationship Priority

Before placing a new feature, classify its relationship:

- Strongly related to the current row or card: place it in the row, card, or inspector.
- Related to the current list or queue: place it in the list toolbar, filter area, or batch action area.
- Related to the global system: place it in the sidebar, status strip, or global header.
- Related to async feedback: use toast, message, progress, or log.
- Related to complex approval or configuration: use drawer or modal, while preserving the triggering object context.

### Real Data Stress Testing

After generating a product UI, validate with realistic pressure data instead of only ideal copy:

- Very long item names.
- Very long metadata.
- Multiple status tags.
- Batch selection and batch actions.
- Error, blocked, failed, or risk states.
- Empty state and loading state.
- Permission denied, approval pending, or read-only state.
- Long Chinese and mixed Chinese/English technical text.
- Dense rows, narrow columns, and small viewport behavior.

If a requested deliverable includes validation or leadership-facing proof, recommend or generate a `stress-test.html` / comparison page with baseline, edited, error/edge, and before/after report views.

### Multi-Page Product Registry

For product systems with more than one page type, avoid letting each page drift into a separate AI interpretation:

- Before generating a new page type, check whether `design.md` covers that layout pattern.
- If the layout pattern is missing, extend `design.md` or create a target-specific rule before generating the final UI.
- Maintain or recommend `page-registry.md` for multi-page systems.
- `page-registry.md` should map page types to their `target.md`, source frame, reusable components, known states, and validation notes.
- Treat page registry entries as continuity constraints for future pages.

### Figma Write-Back Limits

When writing back to Figma through MCP or automation, state tool-chain limits early and choose a fallback:

- Reliable operations usually include cloning nodes, moving nodes, resizing frames, changing fills/strokes, adjusting spacing, and creating simple layouts.
- Risky operations may include editing text that uses unavailable local fonts, applying remote style libraries, switching complex component variants, preserving all constraints in detached instances, and editing locked or library-owned assets.
- If the exact source font cannot be loaded, use the product-approved fallback font and record the deviation. For Chinese UI, prefer `Noto Sans SC` / `Noto Sans CJK SC` as the fallback and avoid falling back to `Inter`.
- If a component variant cannot be switched safely, clone the closest visible variant and annotate the intended state.
- Never modify original Figma assets directly; clone first, then edit the clone.
- Validate Figma writes with screenshots and metadata before calling the work complete.

## Output Requirements

Always produce:

- `design.md`

When the target artifact is known, also produce:

- `target.md`

When useful, also produce:

- `design-analysis.json` summary
- Claude / Cursor / Codex prompts
- `SKILL.md` derivative for the specific product
- A validation checklist
- Component Inventory
- `page-registry.md` for multi-page systems
- Before / After comparison notes or redline annotations for QA

## Quality Check

Before finalizing `design.md`, verify:

- It names the source product and source materials.
- It separates color roles instead of dumping color tokens.
- It records brand confidence and weak evidence.
- It makes confidence operational, especially for low-confidence colors and accents.
- It records authoritative token sources when available.
- It includes or recommends Component Inventory when source components exist.
- It includes clone, adaptive layout, information hierarchy, local edit, and anti AI-default-color rules.
- If a target artifact is known, it produces a separate `target.md` with required modules, business objects, and anti-patterns.
- For multi-page systems, it records or recommends a page registry.
- It explains how future AI outputs should preserve the original system.
- It avoids generic SaaS language when the source has specific product style.

## When Unsure

If evidence is weak, say so in `design.md`. Prefer conservative generation rules over confident invention.
